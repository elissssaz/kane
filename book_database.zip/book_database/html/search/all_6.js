var searchData=
[
  ['tf_5fbuffer_5f_9',['tf_buffer_',['../classCylinderDetector.html#a19ed13691185ff741946d5eff61f1a74',1,'CylinderDetector']]],
  ['tf_5flistener_5f_10',['tf_listener_',['../classCylinderDetector.html#a846bf510138780410a1c9be524eda51e',1,'CylinderDetector']]]
];
