#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"  // For publishing point coordinates
#include <string>
#include <map>
#include <iostream>
#include <chrono>
#include <thread>
 
struct Book {
    std::string title;
    bool available;
    float x;  // X-coordinate in the map
    float y;  // Y-coordinate in the map
};
 
class BookDatabaseNode : public rclcpp::Node {
public:
    BookDatabaseNode() : Node("book_database_node") {
        initialize_books();
        print_available_books();
 
        // Publisher for borrowing books
        borrow_publisher_ = this->create_publisher<std_msgs::msg::String>("borrow_book", 10);
 
        // Publisher for custom point topic in Rviz
        point_publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>("book_goal_point", 10);
 
        // Publisher for navigation points for the robot
        navigate_publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>("navigate_to_book", 10);
 
        // Initialize the last borrow time
        last_borrow_time_ = this->now();
 
        // Start the user input thread
        user_input_thread_ = std::thread(&BookDatabaseNode::handle_user_input, this);
    }
 
    ~BookDatabaseNode() {
        if (user_input_thread_.joinable()) {
            user_input_thread_.join();  // Ensure the thread is joined before destruction
        }
    }
 
private:
    std::map<std::string, Book> books_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr borrow_publisher_;
    rclcpp::Publisher<geometry_msgs::msg::PointStamped>::SharedPtr point_publisher_;
    rclcpp::Publisher<geometry_msgs::msg::PointStamped>::SharedPtr navigate_publisher_;
    rclcpp::Time last_borrow_time_; // To track the last time a borrow attempt was processed
    std::thread user_input_thread_;
 
    void initialize_books() {
        books_["1984"] = Book{"1984", true, 7.0, 2.21535 };   
        books_["Pride and Prejudice"] = Book{"Pride and Prejudice", true, 7.0, 1.244027}; 
books_["To Kill a Mockingbird"] = Book{"To Kill a Mockingbird", true, 7.0, 0.77553 }; 
books_["The Great Gatsby"] = Book{"The Great Gatsby", true, 7.0, -1.61863 };
 
// Additional books with their own coordinates
books_["The Hunger Games"] = Book{"The Hunger Games", true, 2.925824, -3.9};   
books_["Divergent"] = Book{"Divergent", true, 3.69138, 0.2}; 
books_["IT Chapter 2"] = Book{"IT Chapter 2", true, 4.732185, -1.2}; 
books_["IT"] = Book{"IT", true, 2.69425, -1.69643}; 
books_["Origin"] = Book{"Origin", true, 0.0, 0.0};  
    }
 
    void print_available_books() {
        std::cout << "\nAvailable Books:\n";
        for (const auto& [title, book] : books_) {
            if (book.available) {
                std::cout << "- " << title << std::endl;
            }
        }
        std::cout << std::endl;
    }
 
    void borrow_book_callback(const std_msgs::msg::String::SharedPtr msg) {
        auto current_time = this->now();
        auto time_diff = current_time - last_borrow_time_;
 
        // Only proceed if the last message was processed more than 1 second ago
        if (time_diff.seconds() >= 1.0) {
            std::string book_title = msg->data;
            auto it = books_.find(book_title);
 
            // Check if the book is available and update availability
            if (it != books_.end() && it->second.available) {
                it->second.available = false;
                std::cout << "\nSuccessfully borrowed: " << book_title << std::endl;
 
                // Publish the book's location as a point
                publish_point(it->second.x, it->second.y, book_title);
            } else {
                std::cout << "\nBook unavailable or not found: " << book_title << std::endl;
            }
 
            // Print the updated list of available books after each borrow request
            print_available_books();
 
            // Update the last borrow time
            last_borrow_time_ = current_time;
        }
    }
 
    void publish_point(float x, float y, const std::string& book_title) {
        geometry_msgs::msg::PointStamped point_msg;
        point_msg.header.stamp = this->now();
        point_msg.header.frame_id = "map";  // Change to "odom" if necessary
 
        // Set point coordinates
        point_msg.point.x = x;
        point_msg.point.y = y;
        point_msg.point.z = 0.0;
 
        // Debug message to confirm point is being published
        std::cout << "Publishing point for: " << book_title 
<< " at coordinates (" << x << ", " << y << ")" << std::endl;
 
        // Publish the point for navigation to the robot
        navigate_publisher_->publish(point_msg);
        // Publish the point for visualization in Rviz
        point_publisher_->publish(point_msg);
    }
 
    void handle_user_input() {
        while (rclcpp::ok()) {
            std::string input;
            std::cout << "Enter the title of the book to borrow: ";
            std::getline(std::cin, input);
 
            // If the input is not empty, process the borrowing
            if (!input.empty()) {
                // Create and publish the message
                auto msg = std_msgs::msg::String();
                msg.data = input;
 
                // Publish to the borrow topic
                borrow_publisher_->publish(msg);
 
                // Trigger the borrowing callback directly for immediate response
                borrow_book_callback(std::make_shared<std_msgs::msg::String>(msg));
                // Ask if the user wants to borrow another book
                char another;
                std::cout << "Do you want to borrow another book? (Y/N): ";
                std::cin >> another;
                std::cin.ignore(); // Ignore the newline character left in the buffer
                if (another != 'Y' && another != 'y') {
                    std::cout << "Exiting the book borrowing process." << std::endl;
                    break;  // Exit the loop
                }
 
                // If 'Y' is selected, clear the screen for a better UX
                std::cout << "\033[2J\033[1;1H"; // ANSI escape code to clear the console
                print_available_books();
            }
        }
    }
};
 
int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    // Create the node and spin in a separate thread
    auto book_database_node = std::make_shared<BookDatabaseNode>();
    std::thread spin_thread([&]() { rclcpp::spin(book_database_node); });
 
    // Wait for user input
    std::cout << "Press Ctrl+C to exit." << std::endl;
 
    // Join the spin thread when done
    if (spin_thread.joinable()) {
        spin_thread.join();
    }
 
    rclcpp::shutdown();
    return 0;
}